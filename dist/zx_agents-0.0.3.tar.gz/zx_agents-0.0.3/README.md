# zx-agents
这是一个自定义的 OpenAI 代理配置包。

## 安装
```bash
pip install zx-agents
```